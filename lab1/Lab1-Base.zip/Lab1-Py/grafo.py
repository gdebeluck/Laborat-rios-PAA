from collections import deque


class Grafo:
    def __init__(self, numero_vertices: int) -> None:
        self.numero_vertices = numero_vertices
        # TODO: escolha e inicialize aqui a representação interna do grafo.
        raise NotImplementedError

    def vertices(self) -> list[int]:
        # TODO: implemente este método.
        raise NotImplementedError

    def adicionar_aresta(self, u: int, v: int) -> None:
        # TODO: implemente este método.
        raise NotImplementedError

    def remover_aresta(self, u: int, v: int) -> None:
        # TODO: implemente este método.
        raise NotImplementedError

    def sao_adjacentes(self, u: int, v: int) -> bool:
        # TODO: implemente este método.
        raise NotImplementedError

    def grau(self, v: int) -> int:
        # TODO: implemente este método.
        raise NotImplementedError

    def vizinhos(self, v: int) -> list[int]:
        # TODO: implemente este método.
        raise NotImplementedError

    def tem_ciclos_impares(self) -> bool:
        valores = dict[int, int]()
        for inicio in self.vertices():
            if inicio in valores:
                continue
            valores[inicio] = 0
            fila = deque([inicio])
            while fila:
                u = fila.popleft()
                for v in self.vizinhos(u):
                    if v not in valores:
                        valores[v] = 1 - valores[u]
                        fila.append(v)
                    elif valores[v] == valores[u]:
                        return True
        return False
