from grafo import Grafo


def main() -> None:
    # TODO: leia a entrada e construa o grafo correspondente.

    # TODO: determine e imprima a resposta no formato solicitado.
    raise NotImplementedError


if __name__ == "__main__":
    main()
